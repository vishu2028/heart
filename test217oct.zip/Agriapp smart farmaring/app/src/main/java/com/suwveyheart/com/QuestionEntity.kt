package com.suwveyheart.com

import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
                          val question: String,
                          val correct_answer: String,
                          val incorrect_answer: List<String>)
