package com.suwveyheart.com

import retrofit2.Call



import retrofit2.http.GET

interface QuizApiService {
    @GET("api.php?amount=5&category=11&difficulty=easy&type=boolean")
    fun getQuestions(): Call<QuizResponse>
}