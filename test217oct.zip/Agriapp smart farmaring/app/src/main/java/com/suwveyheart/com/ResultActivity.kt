package com.suwveyheart.com

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ResultActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_result)

        val scoreTextView: TextView = findViewById(R.id.scoreTextView)
        val score = intent.getIntExtra("score", 0)
        scoreTextView.text = "Your score: $score"
        val highScoreTextView: TextView = findViewById(R.id.highScoreTextView)
        val totalQuestions = intent.getIntExtra("totalQuestions", 1)
        // Save high score to SharedPreferences
        saveHighScore(score)
        scoreTextView.text = "Your score: $score out of $totalQuestions"

        // Display high score
        val highScore = getHighScore()
        highScoreTextView.text = "Highest score: $highScore"
    }
    private fun saveHighScore(score: Int) {
        val sharedPreferences = getSharedPreferences("quiz_prefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val highScore = sharedPreferences.getInt("high_score", 0)
        if (score > highScore) {
            editor.putInt("high_score", score)
            editor.apply()
        }
    }
    private fun getHighScore(): Int {
        val sharedPreferences = getSharedPreferences("quiz_prefs", Context.MODE_PRIVATE)
        return sharedPreferences.getInt("high_score", 0)
    }
}