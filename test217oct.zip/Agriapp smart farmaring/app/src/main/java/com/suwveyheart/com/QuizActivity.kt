package com.suwveyheart.com

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.Locale

class QuizActivity : AppCompatActivity() {

    private lateinit var questions: List<Question>
    private var currentQuestionIndex = 0
    private var score = 0
    private lateinit var questionTextView: TextView
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var timerTextView: TextView
    private lateinit var countDownTimer: CountDownTimer
    private var timeLeftInMillis = 30000 // 30 seconds

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_quiz2)


        timerTextView = findViewById(R.id.timerTextView)
        questionTextView = findViewById(R.id.questionTextView)
        trueButton = findViewById(R.id.trueButton)
        falseButton = findViewById(R.id.falseButton)

        fetchQuestions()

        trueButton.setOnClickListener { checkAnswer("True") }
        falseButton.setOnClickListener { checkAnswer("False") }
        startTimer()
    }

    private fun fetchQuestions() {
        // Fetch questions from API using Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl("https://opentdb.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(QuizApiService::class.java)
        service.getQuestions().enqueue(object :Callback<QuizResponse> {
            override fun onResponse(p0: Call<QuizResponse>, p1: Response<QuizResponse>) {
              questions = p1.body()?.results ?: emptyList()
                displayQuestion()
            }

            override fun onFailure(p0: Call<QuizResponse>, p1: Throwable) {
                TODO("Not yet implemented")
            }

        }
        )
    }

    private fun displayQuestion() {
        if (currentQuestionIndex < questions.size) {
            val question = questions[currentQuestionIndex]
            questionTextView.text = question.question
        } else {
            endQuiz()
        }
    }

    private fun checkAnswer(userAnswer: String) {
        val correctAnswer = questions[currentQuestionIndex].correct_answer
        if (userAnswer == correctAnswer) {
            score++
        }
        currentQuestionIndex++
        displayQuestion()
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(timeLeftInMillis.toLong(), 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished.toInt()
                updateTimer()
            }

            override fun onFinish() {
                endQuiz()
            }
        }.start()
    }

    private fun updateTimer() {
        val seconds = timeLeftInMillis / 1000
        // Update timer UI if necessary
        timerTextView.text = String.format(Locale.getDefault(), "Time: %d", seconds)
    }

    private fun endQuiz() {
        countDownTimer.cancel()
        val intent = Intent(this, ResultActivity::class.java).apply {
            putExtra("score", score)
        }
        startActivity(intent)
        finish()


    }

    }
